package net.daum.service;

public interface ReplyService {

}
