package net.daum.dao;

import net.daum.vo.MemberVO;

public interface MemberDAO {

	void insertMember(MemberVO m);
	
}
